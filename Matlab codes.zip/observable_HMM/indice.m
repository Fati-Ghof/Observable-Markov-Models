function r= indice (x,MSS)
if x>0
    if x==MSS
        r=1;
    elseif x<MSS && x>=300
        r=2;
    elseif x<300 && x>=100
        r=3;
    elseif x<100
        r=4;
    end
else
    if abs(x)==MSS
        r=5;
    elseif abs(x)<MSS && abs(x)>=300
        r=6;
    elseif abs(x)<300 && abs(x)>=100
        r=7;
    elseif abs(x)<100
        r=8;
    end
end
   