function [AUC,TRUST]=metric_per_class(num_class,test_data,label)

A2=test_data;
for i=1:num_class
    nn(i)=size(find(A2(:,end)==i),1);
end
for i=1:num_class
    t(i)=sum(label==i);
end

AUC(1)=(sum(label(1:nn(1),1)==A2(1:nn(1),end))*100)/nn(1);
TRUST(1)=(sum(label(1:nn(1),1)==A2(1:nn(1),end))*100)/t(1);

for i=2:num_class
    AUC(i)=(sum(label(sum(nn(1:i-1))+1:sum(nn(1:i)),1)==A2(sum(nn(1:i-1))+1:sum(nn(1:i)),end))*100)/nn(i);
    TRUST(i)=(sum(label(sum(nn(1:i-1))+1:sum(nn(1:i)),1)==A2(sum(nn(1:i-1))+1:sum(nn(1:i)),end))*100)/t(i);
end
