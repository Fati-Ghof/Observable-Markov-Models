%% TCP Traffic Classification Using Markov Models

% dataset with 6 classes: 1: http 2:smtp 3:ftp 4:pop3 5:nntp 6:msn
% clo1:labels col2:destination ports col3-col6: length of pkts

% dataset with 10 classes: 1:http 2:smtp 3:ftp 4:pop3 5:nntp 6:msn 7:edonkey 8:ssh 9:bittorrent 10:https
% In the case of ssh and smtp, server sends the first data packet. 
%%
clc,clear all 
A1=dlmread('train_data_tenclass.txt'); 


% markov models
MSS=max(max(abs(A1(:,3:6))));
num_class=10;
l=4; % number of stages
A=zeros(8,8,l-1,num_class); % transition matrix 

for i=1:num_class
    NumTrainFlow_perClass(i)=size(find(A1(:,1)==i),1);
end

q(1)=1;

for i=2:num_class
    q(i)=sum(NumTrainFlow_perClass(1:i-1))+1;
end

for s=1:num_class
    for k=q(s):q(s)+NumTrainFlow_perClass(s)-1
        for i=1:l-1
            ind1=indice(A1(k,i+2),MSS);
            ind2=indice(A1(k,i+3),MSS);
            A(ind1,ind2,i,s)=A(ind1,ind2,i,s)+1;
        end
    end
end
for s=1:num_class
    for i=1:l-1
        sigma(:,:,i,s)=A(:,:,i,s)./(sum(sum(A(:,:,i,s))));
    end
end

% prior probabilities
for s=1:num_class
    p(:,s)=sum(sigma(:,:,1,s),2);
end

% eliminating zero elements of prior probabilities and transition matrix
temp1=sigma==0;
sigma=sigma+temp1.*(10^(-5));

temp2=p==0;
p=p+temp2.*(10^(-5));


% test step
A2=dlmread('test_data_tenclass.txt'); 

 for k=1:size(A2,1)
     pr=zeros(num_class,1);p1=zeros(num_class,1);
     for s=1:num_class
         p1(s,1)=p(indice(A2(k,3),MSS),s);
         for i=1:l-1
             ind1=indice(A2(k,i+2),MSS);
             ind2=indice(A2(k,i+3),MSS);
             pr(s,1)=pr(s,1)+log10(sigma(ind1,ind2,i,s));
        end
     end
     temp3=p1==0;
     p1=p1+temp3.*(10^(-5));
    [val,I]=max(log10(p1)+pr);  
    label1(k)=I;
 end
 
 [AUC,TRUST]=metric_per_class(num_class,A2(:,1),label1')

sum(AUC)/num_class
sum(TRUST)/num_class